import React from 'react'
import {connect} from 'react-redux'

function Counter (props){
    return (
        <div>
            <h1>I am counter</h1>
            <p>Count: {props.count}</p>
            <button
            onClick={props.onIncrementClick}
            >increment</button>
            <button
            onClick={props.onDecrementClick}
            >decrement</button>
        </div>
    )
}
const mapStateFromProps = (state) => {
    return{
        count:state.count
    }
}
const mapDispatchToProps = (dispatch) => {
    return{
        onIncrementClick:() => {
            const action = {type:"INCREMENT"}
            dispatch(action)
        },
        onDecrementClick:() => {
            const action = {type:"DECREMENT"}
            dispatch(action)
        }
    }
}

export default connect(mapStateFromProps,mapDispatchToProps)(Counter)