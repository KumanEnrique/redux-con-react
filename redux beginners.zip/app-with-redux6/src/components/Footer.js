import React from 'react'
import { connect } from 'react-redux';

function Footer (props){
    return(
        <footer>
            <h1>total count:{props.count}</h1>
        </footer>
    )
}
const mapStateToProps = (state)=>{
    return {
        count:state.items.length
    }
}
export default connect(mapStateToProps)(Footer)