import React from 'react'
import {connect} from 'react-redux'
import constants from '../store/constants'

function List (props){
    return(
        <div>
            <h1>i am fine</h1>
            <form onSubmit={props.addList} >
                <input value={props.inputValue} onChange={props.inputChanged} />
            </form>
            <ul>
                {props.items.map((item,index) => {
                    return (
                    <li key={index} onClick={()=>props.removeItem(index)} >{item}  
                    </li>
                    )
                })}
            </ul>
        </div>
    )
}
const mapStateToProps = (state) => {
    return {
        inputValue: state.inputValue,
        items:state.items
    }
}
const mapDispatchToProps = (dispatch) => {
    return{
        inputChanged: (e) => {
            const action = {type:constants.INPUT_CHANGE,text:e.target.value}
            dispatch(action)
        },
        addList: (e) => {
            e.preventDefault()
            const action = {type:constants.ADD_LIST,items:e.target.value}
            dispatch(action)
        },
        removeItem:(index) => {
            console.log(index)
            const action = {type:constants.REMOVE_ITEM,index:index}
            dispatch(action)
        }
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(List)