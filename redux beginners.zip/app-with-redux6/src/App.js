import React from 'react';
import './App.css';

import store from './store/index'
import List from './components/List'
import Footer from './components/Footer'
import {Provider} from 'react-redux'

function App() {
  return (
    <div className="App">
      <Provider store={store}>
        <div>
          <List
          ></List>
          <Footer></Footer>
        </div>
      </Provider>
    </div>
  );
}

export default App;
