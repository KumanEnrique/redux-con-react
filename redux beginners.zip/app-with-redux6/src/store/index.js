import {createStore} from 'redux'
import constants from './constants'

const initialState = {
    inputValue:"",
    items:[]
}
const reducer = (state = initialState,action) =>{
    console.log(action)
    switch (action.type){
        case constants.INPUT_CHANGE:
            return Object.assign({},state,{inputValue:action.text})
        case constants.ADD_LIST:
            return Object.assign({},state,{items:state.items.concat(state.inputValue),inputValue:""})
        case constants.REMOVE_ITEM:
            const copyOfItems = state.items.slice()
            copyOfItems.splice(action.index,1)
            return Object.assign({},state,{items:copyOfItems})
        default:
            return state
    }
}
const store = createStore(reducer)
export default store