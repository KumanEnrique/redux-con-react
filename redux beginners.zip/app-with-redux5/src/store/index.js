import {createStore} from 'redux'


const initialState = {
    inputValue:"",
    items:[]
}
const reducer = (state = initialState,action) =>{
    console.log('state',state)
    switch (action.type){
        case 'INPUT_CHANGE':
            return Object.assign({},state,{inputValue:action.text})
        case 'ADD_LIST':
            return Object.assign({},state,{items:state.items.concat(state.inputValue)})
        default:
            return state
    }
}
const store = createStore(reducer)
export default store