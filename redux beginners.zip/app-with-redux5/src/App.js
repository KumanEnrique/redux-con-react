import React from 'react';
import './App.css';

import store from './store/index'
import List from './components/List'

function App() {
  return (
    <div className="App">
    <List
    store={store}
    ></List>
    </div>
  );
}

export default App;
