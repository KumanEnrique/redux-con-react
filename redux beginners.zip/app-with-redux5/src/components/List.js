import React from 'react'
import {connect} from 'react-redux'

function List (props){
    return(
        <div>
            <h1>i am fine</h1>
            <form onSubmit={props.addList} >
                <input value={props.inputValue} onChange={props.inputChanged} />
            </form>
            <ul>
                {props.items.map((item,index) => {
                    return <li key={index} >{item}</li>
                })}
            </ul>
        </div>
    )
}
const mapStateToProps = (state) => {
    return {
        inputValue: state.inputValue,
        items:state.items
    }
}
const mapDispatchToProps = (dispatch) => {
    return{
        inputChanged: (e) => {
            console.log(e.target.value)
            const action = {type:"INPUT_CHANGE",text:e.target.value}
            dispatch(action)
        },
        addList: (e) => {
            e.preventDefault()
            const action = {type:"ADD_LIST",items:e.target.value}
            dispatch(action)
        }
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(List)