import React from 'react'
import {connect} from 'react-redux'
import Api from '../Api'

function Search (props){
    return (
        <div>
            <h1>Search:</h1>
            <form onSubmit={(e)=>props.handleSubmit(e,props.inputValue)} >
                <input
                    type="text"
                    // value={props.inputValue}
                    onChange={props.handleInputChange}
                    placeholder='repository name'
                />
            </form>
            <ul>
                {props.repos.map(repo =>{
                    return <li key={repo.id}><a href={repo.html_url}> {repo.name}</a> </li>
                })}
            </ul>
        </div>
    )
}
const mapStateToProps = (state) => {
    return {
        inputValue:state.searchInputValue,
        repos: state.repos
    }
}
const mapDispathToProps = (dispatch) =>{
    return {
        handleInputChange:(e) => {
            dispatch({type:"SEARCH_INPUT_CHANGE",value:e.target.value})
        },
        handleSubmit:(e,query) => {
            e.preventDefault()
            Api.getRepos(dispatch,query)
            
        }
    }
}

export default connect(mapStateToProps,mapDispathToProps)(Search)