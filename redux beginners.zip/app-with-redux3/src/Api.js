function getRepos(dispatch,query){
    fetch(`https://api.github.com/search/repositories?q=${query}&per_page=100`)
        .then(response => response.json())
        .then(resultado =>{
            console.log(resultado)
            dispatch({type:"SET_REPOS",repos:resultado.items})
        })
}
export default {
    getRepos
}