import React from 'react';
import './App.css';
import store from './store/index'
import Search from './components/Search'

function App() {
  return (
    <div className="App">
      <Search
      store={store}
      ></Search>
    </div>
  );
}

export default App;
