

export default function createStore(reducer,enhacer){

    if(typeof enhacer !== 'undefined'){
        return enhacer(createStore)(reducer)
    }

    let currentState = undefined
    let currentReducer = reducer
    let listeners = []

    function getState(){
        return currentState
    }
    function dispatch(action){
        currentState = currentReducer(currentState,action)
        // console.log("currentState",currentState)
        for(let i = 0;i<listeners.length;i++){
            const listener = listeners[i]
            listener()
        }
    }
    dispatch({type:"@@redux/INIT"})

    function subscribe(listener){
        listeners.push(listener)
        console.log("listenners",listeners.length)

        let isSubscribed = true

        return function unsubscribe(){
            console.log("unsubscribe")

            if(!isSubscribed){
                return;
            }
            isSubscribed = false
            
            const index = listeners.indexOf(listener)
            listeners.splice(index,1)
        }
    }
    return  {
        getState,
        dispatch,
        subscribe
    }

}