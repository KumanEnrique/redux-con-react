import createStore from './createStore'
// console.log("index2",createStore)
const iniatalState = {
    count:1
}
const reducer = (state = iniatalState,action) => {
    console.log("requaks ",action)
    switch (action.type){
        case "INCREMENT":
            return Object.assign({},state,{count:state.count + 1})
        default:
            return state
    }
}
const store = createStore(reducer,window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__())
/* const store = createStore(reducer,window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__())*/
export default store 