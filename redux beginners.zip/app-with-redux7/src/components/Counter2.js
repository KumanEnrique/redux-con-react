import React from 'react'
import store from '../requacks/index'
console.log(store)
class Counter2 extends React.Component{
    constructor(props){
        super(props)
        this.state = store.getState()
    }
    componentDidMount(){
        this.unsub = store.subscribe(() => {
            this.setState(store.getState())
        })
    }
    componentWillUnmount(){
        this.unsub()
    }
    handleClick(){
        const action = {type:"INCREMENT"}
        store.dispatch(action)
    }
    render(){
        return (
            <div>
                <h1>Counter 2</h1>
                <h3>count: {this.state.count}</h3>
                <button onClick={this.handleClick}>Increment</button>
                <button>Decrement</button>
            </div>
        )
    }
}
export default Counter2