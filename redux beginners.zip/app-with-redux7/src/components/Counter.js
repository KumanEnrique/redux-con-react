import React from 'react'
import store from '../store/index'

class Counter extends React.Component{
    constructor(props){
        super(props)
        this.state = store.getState()
    }
    componentDidMount(){
        this.unsub = store.subscribe(() => {
            this.setState(store.getState())
        })
    }
    componentWillUnmount(){
        this.unsub()
    }
    handleClick(){
        const action = {type:"INCREMENT"}
        store.dispatch(action)
    }
    render(){
        return (
            <div>
                <h1>Counter 1</h1>
                <h3>count: {this.state.count} </h3>
                <button onClick={this.handleClick}>Increment</button>
                <button>Decrement</button>
            </div>
        )
    }
}
export default Counter