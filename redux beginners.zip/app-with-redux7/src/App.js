import React from 'react';
import './App.css';

//import {Provider} from 'react-redux'
import {BrowserRouter as Router,Link,Route} from 'react-router-dom'
import Counter from './components/Counter'
import Counter2 from './components/Counter2'

function App() {
  return (
    <Router>
      <div className="App">
        <nav>
          <Link to="/" >Root</Link>
          <Link to="/counter" >Counter 1</Link>
          <Link to="/counter2" >counter 2</Link>

          <Route path="/counter" component={Counter} ></Route>
          <Route path="/counter2" component={Counter2} ></Route>
        </nav>
      </div>
    </Router>
  );
}

export default App;
