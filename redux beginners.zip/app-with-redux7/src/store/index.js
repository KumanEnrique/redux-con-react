import {createStore} from 'redux'

const iniatalState = {
    count:0
}
const reducer = (state = iniatalState,action) => {
    console.log(action)
    switch (action.type){
        case "INCREMENT":
            return Object.assign({},state,{count:state.count + 1})
        default:
            return state
    }
}
const store = createStore(reducer)
export default store