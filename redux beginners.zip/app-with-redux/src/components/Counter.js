import React from 'react'
import {connect} from 'react-redux'

function Counter (props){
    console.log("counter reder",props)
    return (
        <>
            <h1>I am a Counter</h1>
            <p>Count:{props.count}</p>
            <button 
            onClick={props.onIncrementClick}
            >Increment</button>
            <button 
            
            >Decrement</button>
        </>
    )
}
function mapStateToProps(state){
    console.log("mapStateToProps",state)
    return{
        count:state.count
    }
}
function mapDispatchToProps(dispatch){
    return {
        onIncrementClick:() => {
            console.log("dispatch")
            const action = {type:'INCREMENT'}
            dispatch(action)
        }
    }
}

export default connect(mapStateToProps,mapDispatchToProps)(Counter)