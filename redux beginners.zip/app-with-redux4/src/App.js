import React from 'react';
import './App.css';

import store from './store/index'
import Form from './components/Form'

function App() {
  return (
    <div className="App">
      <Form
      store={store}
      ></Form>
    </div>
  );
}

export default App;
